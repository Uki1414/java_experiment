import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;
import java.util.Enumeration;
import java.util.Vector;

public class SelectButton extends JButton implements State {

    private StateManager stateManager;
    private int lastX, lastY;
    private int startX, startY;
    private MyRectangle selectionRect = null;

    public SelectButton(StateManager stateManager) {
        super("Select");
        this.stateManager = stateManager;
        addActionListener(new SelectListener());
    }

    public void mouseDown(int x, int y) {
        boolean onShape = false;
        for (MyDrawing d : stateManager.getSelectedDrawings()) {
            if (d.contains(x, y)) {
                onShape = true;
                break;
            }
        }

        if (!onShape) {
            stateManager.setSelected(x, y);
        }

        if (stateManager.getSelectedDrawings().isEmpty()) {
            startX = x;
            startY = y;
            selectionRect = new MyRectangle(x, y, 0, 0, Color.black, new Color(0,0,0,0), 1);
            selectionRect.setDashed(true); // 破線を設定
            stateManager.mediator().addDrawing(selectionRect); // Mediatorを直接使って図形を追加
        }
        lastX = x;
        lastY = y;
        stateManager.setRepaint();
    }

    public void mouseDrag(int x, int y) {
        if (selectionRect != null){
            int w = Math.abs(x - startX);
            int h = Math.abs(y - startY);
            int newX = Math.min(x, startX);
            int newY = Math.min(y, startY);

            selectionRect.setLocation(newX, newY);
            selectionRect.setSize(w, h);

            stateManager.clearSelection();
            Vector<MyDrawing> selected = stateManager.getSelectedDrawings();

            java.awt.Rectangle selectBounds = new java.awt.Rectangle(newX, newY, w, h);

            java.util.Enumeration<MyDrawing> e = stateManager.drawingsElements();
            while (e.hasMoreElements()) {
                MyDrawing d = e.nextElement();
                if (d != selectionRect) { 
                    if (d.intersects(selectBounds)) {
                        selected.add(d); 
                        d.setSelected(true); 
                    }
                }
            }
        }else{
            int dx = x - lastX;
            int dy = y - lastY;

            stateManager.move(dx, dy);

            lastX = x;
            lastY = y;
        }
        stateManager.setRepaint();
    }

    public void mouseUp(int x, int y) {
        if (selectionRect != null) {
            stateManager.removeDrawing(selectionRect);
            selectionRect = null;
            stateManager.setRepaint();
        }
    }

    class SelectListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            stateManager.setState(SelectButton.this);
        }
    }
}